create Function Login_Publisher (p_publishername IN varchar2, p_password IN varchar2)
return varchar2
as
 v_count number;
 begin
 select count(*) into v_count from publishers where publishername = p_publishername and password= p_password;
 if (v_count = 0) then
 return 'wrong';
 elsif (v_count = 1) then
 return 'succes';
 else return 'too many';
 end if;
end;
/

