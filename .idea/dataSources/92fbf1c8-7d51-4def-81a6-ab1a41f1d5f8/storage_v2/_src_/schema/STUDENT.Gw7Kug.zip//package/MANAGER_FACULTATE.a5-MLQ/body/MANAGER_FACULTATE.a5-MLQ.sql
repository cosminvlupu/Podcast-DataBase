create PACKAGE BODY manager_facultate IS

    nume_facultate VARCHAR2(100) := 'Facultatea de Informatica din IASI';
    
    
    FUNCTION random_nr_matricol return STUDENTI.NR_MATRICOL%TYPE is 
      v_matr STUDENTI.NR_MATRICOL%TYPE;
      v_temp INTEGER;
    BEGIN
         --PRELUAT DIN SCRIPTUL DE CREARE
         LOOP
           v_matr := FLOOR(DBMS_RANDOM.VALUE(100,999)) || CHR(FLOOR(DBMS_RANDOM.VALUE(65,91))) || CHR(FLOOR(DBMS_RANDOM.VALUE(65,91))) || FLOOR(DBMS_RANDOM.VALUE(0,9));
           select count(*) into v_temp from studenti where nr_matricol = v_matr;
           exit when v_temp=0;
         END LOOP;
      return v_matr;
    END; 

    FUNCTION calculeaza_varsta (data_nastere DATE) RETURN INT AS
    BEGIN
       RETURN FLOOR((g_today_date - data_nastere)/365);
    END calculeaza_varsta;   

    PROCEDURE adauga_student (nume studenti.nume%type, prenume studenti.prenume%type) 
       IS 
        v_id_nou studenti.id%type;
        v_nr_matricol_nou STUDENTI.NR_MATRICOL%type;
       BEGIN
        select max(id)INTO v_id_nou from studenti;
          v_id_nou := v_id_nou + 1;
          v_nr_matricol_nou := random_nr_matricol();
          INSERT INTO STUDENTI values(v_id_nou, v_nr_matricol_nou, nume, prenume, 1, 'A0', 0, SYSDATE, 'nume.prenume@info.uaic.ro', SYSDATE, SYSDATE);
    END adauga_student;
    
    PROCEDURE sterge_student (nr_matr studenti.nr_matricol%type) 
    IS
      v_id_student studenti.id%TYPE;
    BEGIN
      SELECT id INTO v_id_student FROM studenti WHERE nr_matricol = nr_matr;
         DELETE FROM note WHERE id_student = v_id_student;
         DELETE FROM prieteni WHERE id_student1 = v_id_student OR id_student2 = v_id_student;
         DELETE FROM studenti WHERE id = v_id_student;
         
    END sterge_student;
    
    FUNCTION prieteni_zece (p_id_student studenti.id%type)
    RETURN INTEGER AS
      v_nr_prieteni INTEGER;
    BEGIN
      SELECT COUNT(DISTINCT prieteni.id) INTO v_nr_prieteni FROM prieteni 
      JOIN note on id_student = prieteni.id_student2 AND VALOARE = 10
      WHERE prieteni.id_student1 = 1001;
      return v_nr_prieteni;
    END;
        
END manager_facultate;
/

