create FUNCTION get_podcasts return sys_refcursor AS
      c_podcasts sys_refcursor;
    BEGIN 
      OPEN c_podcasts FOR SELECT podcast_id, title, description,genre, published_date FROM podcasts;
    RETURN c_podcasts;
END get_podcasts;
/

