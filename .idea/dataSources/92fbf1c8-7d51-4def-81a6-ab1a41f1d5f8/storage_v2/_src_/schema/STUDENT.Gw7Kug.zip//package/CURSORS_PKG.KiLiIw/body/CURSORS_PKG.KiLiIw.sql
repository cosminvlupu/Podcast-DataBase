create PACKAGE BODY cursors_pkg
IS
  FUNCTION "get_podcasts" RETURN ref_cursor_type
  AS all_podcasts_cursor ref_cursor_type;
BEGIN
  OPEN all_podcasts_cursor FOR
    SELECT podcast_id, title, description,genre, published_date FROM  podcasts;
    RETURN all_podcasts_cursor;
  END;
END;
/

