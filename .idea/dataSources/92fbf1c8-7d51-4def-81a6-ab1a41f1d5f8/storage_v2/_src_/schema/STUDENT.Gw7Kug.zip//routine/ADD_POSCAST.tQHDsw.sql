create PROCEDURE add_poscast(titlu IN VARCHAR2, descriere IN VARCHAR2, gen IN VARCHAR2, datap IN DATE, succes OUT INTEGER) AS
   v_numar NUMBER;
BEGIN
  SELECT max(podcast_id)+1 into v_numar from podcasts;
  INSERT INTO PODCASTS (podcast_id, title, description, genre, published_date)
  VALUES (v_numar, titlu, descriere, gen, datap);
  succes := 1;
END;
/

