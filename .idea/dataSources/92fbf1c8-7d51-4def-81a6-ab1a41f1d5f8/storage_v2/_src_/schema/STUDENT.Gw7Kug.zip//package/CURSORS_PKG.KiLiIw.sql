create PACKAGE cursors_pkg IS
  TYPE ref_cursor_type IS RECORD (
    podcastId NUMBER
  , title VARCHAR2(40)
  , description VARCHAR2(200)
  , genre VARCHAR2(10)
  , publishedDate DATE
  );
  TYPE all_podcasts_cursor IS REF CURSOR RETURN ref_cursor_type;
  FUNCTION get_podcasts RETURN ref_cursor_type;
END;

CREATE OR REPLACE PACKAGE BODY "cursors_pkg"
IS
  FUNCTION "get_podcasts" RETURN ref_cursor_type
  AS all_podcasts_cursor ref_cursor_type;
BEGIN
  OPEN all_podcasts_cursor FOR
    SELECT podcast_id, title, description,genre, published_date FROM  podcasts;
    RETURN all_podcasts_cursor;
  END;
END;


CREATE OR REPLACE PROCEDURE add_poscast(titlu IN VARCHAR2, descriere IN VARCHAR2, gen IN VARCHAR2, datap IN DATE, succes OUT INTEGER) AS
   v_numar NUMBER;
BEGIN
  SELECT max(podcast_id)+1 into v_numar from podcasts;
  INSERT INTO PODCASTS (podcast_id, title, description, genre, published_date)
  VALUES (v_numar, titlu, descriere, gen, datap);
  succes := 1;
END;

BEGIN
  add_poscast ('titlu','descriere','horror', sysdate);
END;

select * from podcasts where podcast_id = 1000003;

















Create or replace Procedure Create_User (p_username IN varchar2, p_email IN varchar2, p_password IN varchar2) as
 v_numar int;
begin
SELECT max(podcast_id)+1 into v_numar from podcasts;
insert into Users (user_id,username,creation_date,email,password)
values
(v_numar,p_username,current_date,p_email,p_password);
end ;

create or replace  Function Login_User (p_username IN varchar2, p_password IN varchar2)
return varchar2
as
 v_count number;
 begin
 select count(*) into v_count from users where username = p_username and password= p_password ;
 if (v_count = 0) then
 return 'wrong';
 elsif (v_count = 1) then
 return 'succes';
 else return 'too many';
 end if;
end;

create or replace Function Login_Publisher (p_publishername IN varchar2, p_password IN varchar2)
return varchar2
as
 v_count number;
 begin
 select count(*) into v_count from publishers where publishername = p_publishername and password= p_password;
 if (v_count = 0) then
 return 'wrong';
 elsif (v_count = 1) then
 return 'succes';
 else return 'too many';
 end if;
end;

create or replace procedure Change_email(p_email in varchar2,p_username in varchar2) as
begin
update users set email = p_email where username = p_username;
end;

create or replace Procedure Change_password(p_username in varchar2,p_password in varchar2)as
begin
update users set password = p_password where username = p_username;
end;


create or replace Procedure Rate(p_user_id in number,p_podcast_id in int,p_value in int) as
begin
insert into rating (user_id,podcast_id,rating_date,value)
values
(p_user_id,p_podcast_id,current_date,p_value);
end;

create or replace Procedure Follow(p_user_id in int,p_podcast_id in int) as
begin
insert into following (user_id,podcast_id,follow_date)
values
(p_user_id,p_podcast_id,current_date);
end;

create or replace Procedure Add_podcast(p_publisher_id in varchar2,p_title in varchar2) as
declare v_id int;
begin
SELECT max(podcast_id)+1 into v_id from podcasts;
insert into Podcasts(podcast_id,title,published_date)
values
(v_id,p_title,current_date);
insert into Published(publisher_id,podcast_id)
values
(p_publisher_id,v_id);
SELECT max(podcast_id)+1 into v_numar from podcasts;
end;

create or replace Procedure Add_description(p_podcast_id int,p_description varchar2(200)) as
begin
update podcast set desciption = p_description where podcast_id = p_podcast_id
end

create or replace Procedure Add_description(p_podcast_id int,p_genre varchar2(20)) as
begin
update podcast set genre = p_genre where podcast_id = p_podcast_id
end

create or replace Procedure Add_actor(p_first_name varchar2(20),p_last_name varchar2(20)) as
begin
insert into Actors (first_name,last_name)
values(p_first_name,p_last_name)
end

create or replace Procedure Add_acts(p_actor_id int, p_podcast_id int) as
begin
insert into Acts(actor_id,podcast_id)
values(p_actor_id,p_podcast_id)
end

create or replace Procedure Add_writer(p_first_name varchar2(20),p_last_name varchar2(20)) as
begin
insert into Writers (first_name,last_name)
values(p_first_name,p_last_name)
end

create or replace Procedure Add_writes(p_writer_id int, p_podcast_id int) as
begin
insert into Writes(writer_id,podcast_id)
values(p_writer_id,p_podcast_id)
end

create or replace Procedure Add_directpr(p_first_name varchar2(20),p_last_name varchar2(20)) as
begin
insert into Directors (first_name,last_name)
values(p_first_name,p_last_name)
end

create or replace Procedure Add_acts(p_director_id int, p_podcast_id int) as
begin
insert into Directs(director_id,podcast_id)
values(p_director_id,p_podcast_id)
end

create or replace Function score(p_podcast_id) return int as
declare 
v_avg1 int
v_followers int
v_avg2 int
v_followers30 int
begin
 select avg(value) into v_avg1 from rating where podcast_id = p_podcast_id
 select count(*) into v_followers from following where podcast_id = p_podcast_id
 select avg(value) into v_avg2 from rating where podcast_id = p_podcast_id
 select count(*) into v_followers30 from following where podcast_id = p_podcast_id
 return( (v_avg1 + v_followers)/2 + (v_avg2 + v_followers30)/2 )

end

create or replace Procedure Top(p_top_number int, p_genre varchar2(10) default NULL, p_days int default NULL)
as
begin

end
/

