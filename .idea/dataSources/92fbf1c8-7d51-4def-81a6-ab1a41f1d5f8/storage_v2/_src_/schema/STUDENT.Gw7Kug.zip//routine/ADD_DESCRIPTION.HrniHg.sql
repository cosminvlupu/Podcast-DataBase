create Procedure Add_description(p_podcast_id in int,p_genre in varchar2) as
begin
update podcasts set genre = p_genre where podcast_id = p_podcast_id;
end;
/

