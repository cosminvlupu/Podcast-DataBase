create Procedure Follow(p_user_id in int,p_podcast_id in int) as
begin
insert into following (user_id,podcast_id,follow_date)
values
(p_user_id,p_podcast_id,current_date);
end;
/

