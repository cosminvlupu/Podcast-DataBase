create PROCEDURE export_tabel(nume_tabel IN VARCHAR2) AS
  v_fisier UTL_FILE.FILE_TYPE;

  v_id_prof INT;
  v_nume VARCHAR2(15);
  v_prenume VARCHAR2(30);
  v_grad_didactic VARCHAR2(20);
  v_created_at DATE;
  v_updated_at DATE;
  
  v_cursor_id NUMBER;
  v_cursor_id2 NUMBER;
  v_ok NUMBER;
  v_rec_tab DBMS_SQL.DESC_TAB;
  v_nr_col NUMBER;
  v_total_coloane NUMBER; 
BEGIN
  v_fisier:=UTL_FILE.FOPEN('MYDIR','export.sql','W');   
  UTL_FILE.PUTF(v_fisier,'DROP TABLE '|| nume_tabel ||' CASCADE CONSTRAINTS; / \n');
  
  UTL_FILE.PUTF(v_fisier,'CREATE TABLE '|| nume_tabel ||'(\n');
  v_cursor_id  := DBMS_SQL.OPEN_CURSOR;
  DBMS_SQL.PARSE(v_cursor_id , 'SELECT * FROM '||nume_tabel, DBMS_SQL.NATIVE);
  v_ok := DBMS_SQL.EXECUTE(v_cursor_id);
  DBMS_SQL.DESCRIBE_COLUMNS(v_cursor_id, v_total_coloane, v_rec_tab);
  
  v_nr_col := v_rec_tab.first;
  IF (v_nr_col IS NOT NULL) THEN
    LOOP
      UTL_FILE.PUTF(v_fisier,v_rec_tab(v_nr_col).col_name ||' ' || getType(v_rec_tab, v_nr_col));
      
      IF(v_rec_tab(v_nr_col).col_null_ok = false) THEN 
        UTL_FILE.PUTF(v_fisier,' NOT NULL\n');
      ELSE UTL_FILE.PUTF(v_fisier,'\n');
      END IF;
      v_nr_col := v_rec_tab.next(v_nr_col);
      IF (v_nr_col is not NULL) then
        UTL_FILE.PUTF(v_fisier,', \n');
      END IF;
      EXIT WHEN (v_nr_col IS NULL);
    END LOOP;
  END IF;
  UTL_FILE.PUTF(v_fisier,') / \n');
  --UTL_FILE.FCLOSE(v_fisier);
  
  
  v_cursor_id2 := DBMS_SQL.OPEN_CURSOR;
  DBMS_SQL.PARSE(v_cursor_id2, 'SELECT id, nume, prenume, grad_didactic, created_at,updated_at FROM profesori', DBMS_SQL.NATIVE);
  
  DBMS_SQL.DEFINE_COLUMN(v_cursor_id2, 1, v_id_prof); 
  DBMS_SQL.DEFINE_COLUMN(v_cursor_id2, 2, v_nume,15); 
  DBMS_SQL.DEFINE_COLUMN(v_cursor_id2, 3, v_prenume,30);
  DBMS_SQL.DEFINE_COLUMN(v_cursor_id2, 4, v_grad_didactic,20);
  DBMS_SQL.DEFINE_COLUMN(v_cursor_id2, 5, v_created_at);
  DBMS_SQL.DEFINE_COLUMN(v_cursor_id2, 6, v_updated_at);
  
  v_ok := DBMS_SQL.EXECUTE(v_cursor_id2);

  LOOP 
     IF DBMS_SQL.FETCH_ROWS(v_cursor_id2)>0 THEN 
         DBMS_SQL.COLUMN_VALUE(v_cursor_id2, 1, v_id_prof); 
         DBMS_SQL.COLUMN_VALUE(v_cursor_id2, 2, v_nume); 
         DBMS_SQL.COLUMN_VALUE(v_cursor_id2, 3, v_prenume); 
         DBMS_SQL.COLUMN_VALUE(v_cursor_id2, 4, v_grad_didactic); 
         DBMS_SQL.COLUMN_VALUE(v_cursor_id2, 5, v_created_at); 
         DBMS_SQL.COLUMN_VALUE(v_cursor_id2, 6, v_updated_at); 
 
         UTL_FILE.PUTF(v_fisier,'INSERT INTO ' || nume_tabel || '(id, nume, prenume, grad_didactic, created_at,updated_at)' || 
                                'VALUES( ' || v_id_prof || ', ' ||
                              '''' || v_nume || '''' ||', ' ||
                              '''' || v_prenume || '''' ||', ' ||
                              '''' || v_grad_didactic || '''' ||', ' ||
                                     v_created_at ||', ' ||
                                     v_updated_at ||', '  || ');/'
                              );
      ELSE 
        EXIT; 
      END IF; 
  END LOOP;   
  
  DBMS_SQL.CLOSE_CURSOR(v_cursor_id2);
  UTL_FILE.FCLOSE(v_fisier);
END;
/

