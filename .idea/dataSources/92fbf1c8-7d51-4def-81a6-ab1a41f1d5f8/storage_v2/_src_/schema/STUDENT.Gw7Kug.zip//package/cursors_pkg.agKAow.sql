create PACKAGE "cursors_pkg"
IS
  TYPE ref_cursor_type IS REF CURSOR;
  FUNCTION "get_podcasts" RETURN ref_cursor_type;
END;
/

