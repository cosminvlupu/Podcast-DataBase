create Procedure Add_actor(p_first_name in  varchar2,p_last_name in varchar2) as
v_id int;
begin
SELECT max(actor_id)+1 into v_id from actors;
insert into Actors (actor_id, first_name,last_name)
values(v_id, p_first_name,p_last_name);
end;
/

