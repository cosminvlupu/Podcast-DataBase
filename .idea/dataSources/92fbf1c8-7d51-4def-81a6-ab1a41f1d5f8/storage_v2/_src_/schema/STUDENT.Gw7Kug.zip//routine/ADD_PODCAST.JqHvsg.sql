create Procedure Add_podcast(p_publisher_id in varchar2,p_title in varchar2) as
v_id int;
begin
SELECT max(podcast_id)+1 into v_id from podcasts;
insert into Podcasts(podcast_id,title,published_date)
values
(v_id,p_title,current_date);
insert into Published(publisher_id,podcast_id)
values
(p_publisher_id,v_id);
end;
/

