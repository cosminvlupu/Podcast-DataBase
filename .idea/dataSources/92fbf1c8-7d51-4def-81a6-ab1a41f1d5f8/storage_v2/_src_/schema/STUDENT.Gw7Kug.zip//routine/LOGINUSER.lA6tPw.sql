create Procedure LoginUser (p_username IN varchar2, p_password IN varchar2, mesaj OUT varchar2)
as
 v_count number;
 begin
 select count(*) into v_count from users where username = p_username and password= p_password ;
 if (v_count = 0) then
 mesaj :=  'wrong';
 elsif (v_count = 1) then
 mesaj:= 'succes';
 else mesaj:= 'too many';
 end if;
end;
/

