create PACKAGE manager_facultate IS
      g_today_date   DATE:= SYSDATE;
      CURSOR lista_studenti IS SELECT nr_matricol, nume, prenume, grupa, an FROM studenti ORDER BY nume;
     PROCEDURE adauga_student (nume studenti.nume%type, prenume studenti.prenume%type);
     PROCEDURE sterge_student (nr_matr studenti.nr_matricol%type);
     FUNCTION prieteni_zece (p_id_student studenti.id%type) RETURN INTEGER;
END manager_facultate;
/

