create Procedure Add_acts(p_actor_id in int, p_podcast_id in int) as
begin
insert into Acts(actor_id,podcast_id)
values(p_actor_id,p_podcast_id);
end;
/

