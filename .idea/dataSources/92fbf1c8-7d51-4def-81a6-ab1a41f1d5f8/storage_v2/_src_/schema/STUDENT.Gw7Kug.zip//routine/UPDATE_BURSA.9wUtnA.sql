create PROCEDURE update_bursa(
    pi_matricol IN CHAR)
AS
  v_bursa studenti.bursa%type; 
  student_inexistent EXCEPTION;
  PRAGMA EXCEPTION_INIT(student_inexistent, -20001);
  bursa_prea_mare EXCEPTION;
  PRAGMA EXCEPTION_INIT(bursa_prea_mare, -20002);
BEGIN
  SELECT bursa INTO v_bursa FROM studenti WHERE id = pi_matricol;
  IF (v_bursa + 2000 > 3000) THEN
    UPDATE studenti SET bursa = 3000 WHERE id = pi_matricol;
    RAISE bursa_prea_mare;
  ELSE
    UPDATE studenti SET bursa = v_bursa + 2000 WHERE id = pi_matricol;
  END IF;
  EXCEPTION
  WHEN no_data_found THEN
    RAISE student_inexistent;
END update_bursa;
/

