create trigger MODIFY_VALUE
  instead of insert
  on NT
  for each row
DECLARE
  v_valoare note.valoare%type DEFAULT 0;
BEGIN
    SELECT valoare INTO v_valoare FROM note WHERE ID_STUDENT = :NEW.id_student AND ID_CURS = :NEW.id_curs;
    IF (v_valoare < :NEW.valoare) THEN
      UPDATE note SET valoare = :NEW.valoare WHERE ID_STUDENT = :NEW.id_student AND ID_CURS = :NEW.id_curs;
    END IF;
    EXCEPTION
    WHEN no_data_found THEN
      INSERT INTO note VALUES(:NEW.id, :NEW.id_student, :NEW.id_curs, :NEW.valoare, :NEW.data_notare, :NEW.created_at, :NEW.updated_at);
END;
/

