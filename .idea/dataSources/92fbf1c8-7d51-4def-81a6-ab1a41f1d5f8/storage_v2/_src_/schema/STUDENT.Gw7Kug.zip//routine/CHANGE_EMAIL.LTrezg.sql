create procedure Change_email(p_email in varchar2,p_username in varchar2) as
begin
update users set email = p_email where username = p_username;
end;
/

