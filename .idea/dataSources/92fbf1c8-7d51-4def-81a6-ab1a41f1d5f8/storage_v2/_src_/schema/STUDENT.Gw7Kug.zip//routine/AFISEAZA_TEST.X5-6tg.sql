create PROCEDURE afiseaza_test (in_nume VARCHAR2, out_nume OUT VARCHAR2) AS
BEGIN
   DBMS_OUTPUT.PUT_LINE('Ma cheama ' || in_nume);
   out_nume:= in_nume;
END afiseaza_test;
/

