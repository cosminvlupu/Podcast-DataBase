create PACKAGE BODY studenti1 IS
  procedure adauga_studenti(student detalii_student) AS  
  v_nume studenti.nume%type;
  v_prenume studenti.nume%type;
  v_materii_picate number;
  v_index number := 1;
  cursor detalii is select s.nume,s.prenume, count(n.valoare) from studenti s join note n on s.id = n.id_student where n.valoare < 5 group by s.NUME, s.PRENUME;
  type v_std_linie IS TABLE OF detalii%ROWTYPE;
      begin
        open detalii;
        SELECT * BULK COLLECT INTO v_std_linie FROM detalii;
      close detalii;
  
  end adauga_studenti;
end studenti1;
/

