create FUNCTION make_waves(p_sir_caractere varchar2)
RETURN varchar2 AS
   v_index INTEGER;
   v_rezultat varchar2(1000) := '';
BEGIN
    FOR v_index IN 1..length(p_sir_caractere) LOOP
        IF(v_index MOD 2 = 1)
        THEN
           v_rezultat := v_rezultat || UPPER(SUBSTR(p_sir_caractere,v_index,1));
        ELSE
           v_rezultat := v_rezultat || LOWER(SUBSTR(p_sir_caractere,v_index,1));
        END IF;
    END LOOP;
    return v_rezultat;
END;
/

