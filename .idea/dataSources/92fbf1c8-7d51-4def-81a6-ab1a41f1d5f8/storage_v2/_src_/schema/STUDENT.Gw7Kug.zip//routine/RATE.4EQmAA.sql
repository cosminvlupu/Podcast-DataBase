create Procedure Rate(p_user_id in number,p_podcast_id in int,p_value in int) as
begin
insert into rating (user_id,podcast_id,rating_date,value)
values
(p_user_id,p_podcast_id,current_date,p_value);
end;
/

