create Procedure Top(p_top_number in int, p_genre in varchar2 default NULL, p_days in int default 0)
as
v_id int;
CURSOR cursor_scor IS
          SELECT * FROM notele ORDER BY scor;
     v_rand  notele%ROWTYPE;
begin
SELECT max(podcast_id)+1 into v_id from podcasts;
for v_i in 2000..2100 loop
  insert into notele(podcast_id, scor) values (v_i, score(v_i));
end loop;
FOR v_rand IN cursor_scor LOOP
          DBMS_OUTPUT.PUT_LINE(v_rand.podcast_id ||' ' || v_rand.scor);
     END LOOP;
end;
/

