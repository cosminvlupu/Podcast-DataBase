create TYPE id_prieteni AS TABLE OF INT;
/

