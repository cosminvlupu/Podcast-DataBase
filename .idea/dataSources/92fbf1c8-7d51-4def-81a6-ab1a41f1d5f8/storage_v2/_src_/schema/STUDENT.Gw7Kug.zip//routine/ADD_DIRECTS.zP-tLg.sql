create Procedure Add_directs(p_director_id in int, p_podcast_id in int) as
begin
insert into Directs(director_id,podcast_id)
values(p_director_id,p_podcast_id);
end;
/

