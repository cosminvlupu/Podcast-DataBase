create Procedure Add_writes(p_writer_id in int, p_podcast_id in int) as
begin
insert into Writes(writer_id,podcast_id)
values(p_writer_id,p_podcast_id);
end;
/

