create PACKAGE studenti1 IS
  type detalii_student is record (
  ID STUDENTI.ID%type,
  nume STUDENTI.NUME%type,
  prenume STUDENTI.PRENUME%type
  );
  v_student detalii_student; 
  procedure adauga_studenti(v_student detalii_student);
END studenti1;
/

