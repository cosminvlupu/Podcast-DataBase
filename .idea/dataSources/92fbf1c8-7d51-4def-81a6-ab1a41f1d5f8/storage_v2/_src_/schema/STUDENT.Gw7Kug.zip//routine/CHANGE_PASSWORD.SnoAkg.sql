create Procedure Change_password(p_username in varchar2,p_password in varchar2)as
begin
update users set password = p_password where username = p_username;
end;
/

