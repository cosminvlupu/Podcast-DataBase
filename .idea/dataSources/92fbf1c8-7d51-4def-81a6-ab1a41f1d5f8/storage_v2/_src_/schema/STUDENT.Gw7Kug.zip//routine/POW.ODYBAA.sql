create PROCEDURE pow (p_baza IN Integer := 3, p_exponent IN INTEGER DEFAULT 5, p_out OUT Integer) AS   
BEGIN
    p_out := p_baza ** p_exponent;    
END;
/

