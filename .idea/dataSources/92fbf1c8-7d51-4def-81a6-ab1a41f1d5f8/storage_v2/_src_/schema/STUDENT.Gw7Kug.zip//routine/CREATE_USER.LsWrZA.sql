create Procedure Create_User (p_username IN varchar2, p_email IN varchar2, p_password IN varchar2) as
v_numar int;
begin
SELECT max(podcast_id)+1 into v_numar from podcasts;
insert into Users (user_id,username,creation_date,email,password)
values
(v_numar,p_username,current_date,p_email,p_password);
end ;
/

