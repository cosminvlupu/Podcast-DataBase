create view NT as
SELECT "ID","ID_STUDENT","ID_CURS","VALOARE","DATA_NOTARE","CREATED_AT","UPDATED_AT" FROM note
/

create trigger MODIFY_VALUE
  instead of insert
  on NT
  for each row
-- missing source code
/

