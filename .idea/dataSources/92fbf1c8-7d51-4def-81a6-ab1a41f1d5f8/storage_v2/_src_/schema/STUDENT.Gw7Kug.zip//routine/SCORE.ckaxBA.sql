create Function score(p_podcast_id int) return int as
v_avg1 int;
v_followers int;
v_avg2 int;
v_followers30 int;
begin
 select avg(value) into v_avg1 from rating where podcast_id = p_podcast_id;
 select count(*) into v_followers from following where podcast_id = p_podcast_id;
 select avg(value) into v_avg2 from rating where podcast_id = p_podcast_id and sysdate - rating_date <= 30;
 select count(*) into v_followers30 from following where podcast_id = p_podcast_id and sysdate - follow_date <= 30;
 return( (v_avg1 + v_followers)/2 + (v_avg2 + v_followers30)/2 );
end;
/

